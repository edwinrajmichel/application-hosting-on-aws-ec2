# Hosting-a-website-on-AWS-EC2-Instance
Hosting a website on AWS EC2 Instance with Auto Scaling group, Application Load Balancer and Web Application Firewall (WAF) and Monitor with Cloud Watch and Add Simple Notification Service (SNS) for it. 
